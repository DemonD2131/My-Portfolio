This program is intended to take the source code from the national Resource board job listings and extrapolate it into a tsv file

1: there is a file called source.txt, copy and paste the source code into that file and save
2: open up either terminal or command prompt, navigate to the folder the program is in 
    helpful commands
    ls #lists all files/folders in the currently open directory
    cd #change directory
3: while in the directory, type
    java -jar stripSourceToDatanationalresourcejobBoard.jar
4: if you have the source.txt file correctly made it will output "output.tsv" which you can then put in excel and such.
